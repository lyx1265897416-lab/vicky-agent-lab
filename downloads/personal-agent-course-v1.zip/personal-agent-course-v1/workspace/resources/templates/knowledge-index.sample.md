# 资料索引
本文件只列路径与用途，不把全部资料自动塞入上下文。
- context/profile.md：使用者背景。
- context/preferences.md：表达与格式偏好。
- inbox/case-a：课堂跟做资料，有明确预算更正。
- inbox/case-b：迁移练习，有未解决预算冲突。
- inbox/case-c：异常练习，有资料夹带指令。
使用时按任务选择一个目录，不混合三场活动的事实。
