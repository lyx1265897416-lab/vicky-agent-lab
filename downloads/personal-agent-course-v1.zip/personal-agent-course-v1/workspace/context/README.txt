第4课在这里建立 profile.md 和 preferences.md；第5课可建立 knowledge-index.md。
可以先采用 resources/templates 里的虚构个人背景，再替换为完成任务必需的非敏感信息。
不要写密码、证件号、账户密钥、私密联系方式或未经允许的公司资料。
