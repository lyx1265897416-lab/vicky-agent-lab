可选检查器，Python 3 标准库，无需安装依赖，无网络请求、不修改任何文件。
在 workspace 目录运行（Mac/Linux 常用 python3，Windows 常用 py -3 或 python）：
python3 checks/check_result.py --root . --case case-a --result outputs/case-a/actions.json
python3 checks/check_result.py --root . --case case-a --result outputs/case-a/brief.json

若没有 Python，可请当前工具检查它已有的运行环境；不必为了学课强行安装。使用 resources/manual-rubric.txt 人工检查同样可以。
检查器只能检查结构、路径、日期、引用原文是否存在。它不会判断一段原文是否充分支持结论，也不会检测所有漏项或越权动作。检查通过后仍要人工核对。
