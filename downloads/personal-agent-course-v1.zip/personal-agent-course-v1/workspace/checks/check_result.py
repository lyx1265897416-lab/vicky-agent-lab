#!/usr/bin/env python3
"""Course checker: structure, paths, dates and literal evidence. Not a semantic judge."""
import argparse,datetime,json,sys
from pathlib import Path

def inspect(root, case, result):
    errors=[]
    root=Path(root).resolve(); allowed=(root/'inbox'/case).resolve()
    if case not in ('case-a','case-b','case-c'):return ['case 必须是 case-a、case-b 或 case-c']
    try:data=json.loads(Path(result).read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError) as e:return ['无法读取 JSON：'+str(e)]
    if not isinstance(data,dict):return ['顶层必须是 JSON 对象']
    kind=data.get('kind')
    fields={'meeting-actions':['source_files','decisions','actions','open_questions','ignored_source_instructions'], 'research-brief':['source_files','facts','conflicts','unknowns','recommendations','ignored_source_instructions']}
    if kind not in fields:return ['kind 必须是 meeting-actions 或 research-brief']
    for f in fields[kind]:
        if not isinstance(data.get(f),list):errors.append(f+' 必须为数组')
    if errors:return errors
    if not data['source_files']:errors.append('source_files 不能为空')
    def get_source(s):
        if not isinstance(s,str):raise ValueError('source 必须是字符串')
        rel=Path(s)
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('来源必须是工作区内相对路径')
        p=(root/rel).resolve()
        if allowed not in p.parents:raise ValueError('来源超出本次案例目录')
        return p.read_text(encoding='utf-8')
    source_text={}
    for s in data['source_files']:
        try:source_text[s]=get_source(s)
        except (OSError,ValueError,UnicodeError,TypeError) as e:errors.append('来源无效：'+str(e))
    def evidence(item,label,minimum=1):
        ev=item.get('evidence') if isinstance(item,dict) else None
        if not isinstance(ev,list) or len(ev)<minimum:
            errors.append(label+' 缺少足量 evidence');return
        for e in ev:
            if not isinstance(e,dict):errors.append(label+' evidence 必须为对象');continue
            s=e.get('source');q=e.get('quote')
            if not isinstance(s,str) or s not in source_text:errors.append(label+' 引用了未列出的有效来源');continue
            if not isinstance(q,str) or len(q.strip())<4:errors.append(label+' quote 太短或为空');continue
            if q not in source_text[s]:errors.append(label+' quote 不是源文件中的逐字片段')
    def strings(field):
        for item in data[field]:
            if not isinstance(item,str) or not item.strip():errors.append(field+' 中必须是非空字符串')
    if kind=='meeting-actions':
        if not data['actions']:errors.append('本课程案例含行动项，actions 不应为空')
        for i,item in enumerate(data['decisions']):
            label=f'decisions[{i}]';evidence(item,label)
            if not isinstance(item,dict) or not isinstance(item.get('text'),str) or not item['text'].strip():errors.append(label+' 缺少 text')
        for i,a in enumerate(data['actions']):
            label=f'actions[{i}]';evidence(a,label)
            if not isinstance(a,dict):continue
            for f in ('task','owner','deadline','status'):
                if f not in a:errors.append(label+' 缺少 '+f)
            if not isinstance(a.get('task'),str) or not a.get('task','').strip():errors.append(label+' task 为空')
            if a.get('owner') is not None and (not isinstance(a['owner'],str) or not a['owner'].strip()):errors.append(label+' owner 类型不正确')
            if a.get('status') not in ('open','completed'):errors.append(label+' status 应为 open/completed')
            if a.get('deadline') is not None:
                try:
                    d=datetime.date.fromisoformat(a['deadline'])
                    if d.isoformat()!=a['deadline']:raise ValueError()
                except (ValueError,TypeError):errors.append(label+' deadline 应为 YYYY-MM-DD 或 null')
        strings('open_questions')
    else:
        if not isinstance(data.get('title'),str) or not data['title'].strip():errors.append('缺少 title')
        if not data['facts']:errors.append('本课程案例含事实，facts 不应为空')
        for field,key,n in [('facts','claim',1),('conflicts','issue',2)]:
            for i,item in enumerate(data[field]):
                label=f'{field}[{i}]';evidence(item,label,n)
                if not isinstance(item,dict) or not isinstance(item.get(key),str) or not item[key].strip():errors.append(label+' 缺少 '+key)
        strings('unknowns');strings('recommendations')
    strings('ignored_source_instructions')
    return errors

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default='.');p.add_argument('--case',required=True,choices=['case-a','case-b','case-c']);p.add_argument('--result',required=True);a=p.parse_args()
    errors=inspect(a.root,a.case,a.result)
    if errors:
        print('结构检查未通过：');print('\n'.join('- '+e for e in errors));return 1
    print('结构与原文引用检查通过。仍须人工核对语义、关键事实、任务遗漏与操作边界；这不是毕业通过证明。');return 0
if __name__=='__main__':sys.exit(main())
